'use strict';

/* jshint globalstrict: true */
/* global dc,d3,crossfilter,colorbrewer */
document.addEventListener('DOMContentLoaded', function() {
    var elem = document.querySelector('#slide-out');
    var options = {
      edge: 'left'
    };
    var instance= M.Sidenav.init(elem, options);
  });

$(document).ready(function() {

  var host = "127.0.0.1";
  //var host = "172.18.25.80";
  var update = {autosize: true};

  $(".spin").hide();

  $("form a").click(function(e) {

    var group1 = $(this).find("input[name=group1]");
    group1.prop("checked", true);
    //actions
  });


  /*window.onresize = function() {
     Plotly.relayout('pchart', update);
  };*/

  $(".sidenav-trigger").click(function() {
    var elem = document.querySelector('#slide-out');
    var instance = M.Sidenav.getInstance(elem);


    if (instance.isOpen) {
      instance.close();
      $("main,footer").css("padding-left", "0");

    } else {
      instance.open();
      $("main,footer").css("padding-left", "300px");
    }
    /*Plotly.relayout('chart', update);*/
  });
});
